package nl.welcomenewworld.jetsonbox;

/**
 * IJkrit (puur Java). Wordt ~10x per seconde gevoed met snelheid, versnelling en stilstand.
 * Stappen: 0 stilstaan (3 s) -> 1 optrekken -> 2 topsnelheid 10 s vasthouden -> 3 afremmen -> 4 klaar (of -1 mislukt).
 */
public final class Calibrator {
    public int step = 0;            // 0..4, -1 = mislukt
    public double countdown = 3;    // seconden (stap 0 en 2)
    public String message = "Sta stil, telefoon vast in de houder";
    public double vmaxKmh = 0, accel = 0, decel = 0;

    private double stillT = 0, plateauT = 0, t = 0;
    private double maxV = 0, tAccStart = -1, vAccStart = 0;
    private double holdSum = 0; private int holdN = 0; private double holdMax = 0;
    private double tDecStart = -1, vDecStart = 0;
    private boolean decStarted = false;
    private final double[] hist = new double[20]; private int hi = 0, hn = 0;   // snelheid laatste 2 s (10 Hz)

    /** @param v snelheid m/s, a versnelling m/s2, still stilstand, gps of er een verse GPS-meting is */
    public void update(double dt, double v, double a, boolean still, boolean gps) {
        t += dt;
        hist[hi] = v; hi = (hi + 1) % hist.length; if (hn < hist.length) hn++;
        double slope = hn == hist.length ? (v - hist[hi]) / 2.0 : 1;   // m/s2 over 2 s
        switch (step) {
            case 0:
                if (still) { stillT += dt; countdown = Math.max(0, 3 - stillT); } else { stillT = 0; countdown = 3; }
                message = gps ? "Sta stil, telefoon vast in de houder" : "Wachten op GPS. Sta stil, liefst buiten";
                if (stillT >= 3 && gps) { step = 1; message = "Rij rechtdoor en trek op tot je topsnelheid"; }
                break;
            case 1:
                if (v > 1.0 && tAccStart < 0) { tAccStart = t; vAccStart = v; }
                maxV = Math.max(maxV, v);
                boolean flat = Math.abs(slope) < 0.15 && v > 8 / 3.6 && v > 0.85 * maxV;
                plateauT = flat ? plateauT + dt : 0;
                if (plateauT >= 1.5) {
                    accel = (v - vAccStart) / Math.max(0.5, t - plateauT - tAccStart);
                    step = 2; countdown = 10; message = "Houd je topsnelheid vast";
                }
                if (t > 120) fail("Geen topsnelheid gevonden. Zoek een recht stuk van minstens 150 m.");
                break;
            case 2:
                countdown -= dt; holdSum += v; holdN++; holdMax = Math.max(holdMax, v);
                if (v < 0.6 * maxV) { step = 1; plateauT = 0; message = "Te veel snelheid verloren. Trek opnieuw op"; holdSum = 0; holdN = 0; break; }
                if (countdown <= 0) { step = 3; vDecStart = v; tDecStart = t; message = "Rem nu af tot stilstand"; }
                break;
            case 3:
                if (!decStarted) { if (v < 0.9 * vDecStart) { decStarted = true; tDecStart = t; } else if (t - tDecStart > 40) fail("Afremmen niet herkend. Probeer opnieuw."); break; }
                if (still || v < 0.3) {
                    decel = vDecStart / Math.max(0.5, t - tDecStart);
                    double avg = holdN > 0 ? holdSum / holdN : maxV;
                    vmaxKmh = Math.round(Math.max(avg, 0.97 * holdMax) * 3.6);
                    if (vmaxKmh < 5) fail("Topsnelheid te laag gemeten. Probeer opnieuw.");
                    else { step = 4; message = "Klaar! Vmax " + (int) vmaxKmh + " km/u"; }
                }
                if (t - tDecStart > 40) fail("Afremmen niet herkend. Probeer opnieuw.");
                break;
            default: break;
        }
    }

    private void fail(String why) { step = -1; message = why; }
}
