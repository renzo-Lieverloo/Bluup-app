package nl.welcomenewworld.jetsonbox;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * Geluidsmotor van de JetsonBox (puur Java, geen Android-afhankelijkheden).
 *
 * Model (goedgekeurd in de Bluup-simulator v14):
 *  - zoem-lus loopt als een bandje met afspeelsnelheid r = 0,2 + 0,8 * v/Vmax
 *  - bluups (losse korrels uit de bluup-lus) lopen synchroon met dezelfde bandpositie,
 *    met tussentijd x1,5
 *  - volume = 1 + 0,3 * (1 - (v/Vmax)^2)
 *  - aanloop bij wegrijden: r van 0,04 naar 0,2 in 0,4-1,5 s, volume zwelt aan
 *  - uitloop na stilstand: 12 bluups, elk 0,75x zo hoog en 0,82x zo hard, tot onder 20 Hz
 *  - in-/uitfade per bluup 10% / 30% van de lengte (klikvrij)
 */
public final class BluupSynth {
    public static final int SR = 44100;

    private static final float R0 = 0.2f, RLOW = 0.04f, BOOST = 0.3f;
    private static final float Q = 0.75f, CAP = 0.35f, UIT_VOL = 0.82f;

    private final float[] zoem, bluup;
    private final int L;
    private final int[] bnd;           // 12 grensposities + L
    private final int nGrains;

    // instellingen (mogen live veranderen)
    public volatile float zoemLevel = 0.35f;
    public volatile float spacing = 1.5f;
    public volatile float master = 0.85f;
    public volatile float volume = 1.0f;

    // besturing vanuit de sensorservice
    private volatile float speedFrac = 0f;     // v / Vmax, 0..1
    private volatile boolean moving = false;
    private volatile float accelHint = 0.7f;   // m/s2, voor de lengte van de aanloop
    private volatile float vmaxMs = 26f / 3.6f;

    // interne toestand (alleen audiothread)
    private long clock = 0;                    // samples sinds start
    private double zpos = 0, tau = 0;
    private int gi = 0;
    private float zgPrev = 0;
    private double rPrev = -1;
    private boolean wasMoving = false;
    private double tStart = 0, ta = 1.0;
    private double uitT0 = -1, uitEnd = -1;
    private final ArrayList<Grain> active = new ArrayList<>();

    private static final class Grain {
        long start; int ns; double a; double r; float g; float fi, fo;
    }

    /** Maakt een synth uit een stereo-lus (links zoem, rechts bluups) met automatisch gevonden bluup-grenzen. */
    public static BluupSynth fromStereo(byte[] wav) throws java.io.IOException {
        float[][] zb = readStereoWav(wav);
        float[] bl = zb[1]; int L = bl.length;
        // grenzen zoeken en beide lussen zo draaien dat de eerste grens op 0 valt
        int w = Math.max(1, SR / 300); double acc = 0; float[] env = new float[L];
        for (int i = 0; i < L + w; i++) { acc += Math.abs(bl[i % L]); if (i >= w) acc -= Math.abs(bl[(i - w) % L]); env[i % L] = (float) (acc / w); }
        int span = L / 30, b0 = 0; float mn = Float.MAX_VALUE;
        for (int j = -span; j <= span; j++) { int jj = ((j % L) + L) % L; if (env[jj] < mn) { mn = env[jj]; b0 = jj; } }
        float[] z2 = new float[L], b2 = new float[L];
        for (int i = 0; i < L; i++) { z2[i] = zb[0][(i + b0) % L]; b2[i] = bl[(i + b0) % L]; }
        return new BluupSynth(z2, b2, detectBounds(b2));
    }

    public BluupSynth(float[] zoem, float[] bluup, int[] grainBounds) {
        this.zoem = zoem;
        this.bluup = bluup;
        this.L = Math.min(zoem.length, bluup.length);
        this.nGrains = grainBounds.length;
        this.bnd = new int[nGrains + 1];
        System.arraycopy(grainBounds, 0, bnd, 0, nGrains);
        bnd[nGrains] = L;
    }

    /** Wordt ~100x per seconde aangeroepen door de service. */
    public void setState(float speedMs, boolean isMoving, float accelMs2, float vmaxKmh) {
        if (!Float.isFinite(speedMs)) speedMs = 0f;                     // nooit NaN/oneindig doorgeven
        if (!Float.isFinite(accelMs2)) accelMs2 = 0f;
        if (!Float.isFinite(vmaxKmh) || vmaxKmh < 3.6f) vmaxKmh = 25f;
        vmaxMs = Math.max(1f, vmaxKmh / 3.6f);
        speedFrac = Math.max(0f, Math.min(1f, speedMs / vmaxMs));
        moving = isMoving;
        if (accelMs2 > 0.05f) accelHint = accelMs2;
    }

    private static float vol(float f) { return 1f + BOOST * (1f - f * f); }

    /** Kubische (Catmull-Rom) interpolatie: geen knikjes als de lus langzaam wordt afgespeeld. */
    private static float interp(float[] buf, double pos, int len) {
        pos = pos % len; if (pos < 0) pos += len;
        int i = (int) pos; float t = (float) (pos - i);
        float y0 = buf[(i - 1 + len) % len], y1 = buf[i], y2 = buf[(i + 1) % len], y3 = buf[(i + 2) % len];
        float a = -0.5f * y0 + 1.5f * y1 - 1.5f * y2 + 0.5f * y3;
        float b = y0 - 2.5f * y1 + 2f * y2 - 0.5f * y3;
        float c = -0.5f * y0 + 0.5f * y2;
        return ((a * t + b) * t + c) * t + y1;
    }

    private void addGrain(long startSample, int k, double r, float g, boolean capped) {
        int a = bnd[k], b = bnd[k + 1];
        double real = (b - a) / (double) SR / r;
        if (capped) real = Math.min(real, CAP);
        Grain gr = new Grain();
        gr.start = startSample; gr.ns = (int) (real * SR); gr.a = a; gr.r = r; gr.g = g;
        gr.fi = (float) Math.max(0.002, Math.min(0.03, real * 0.1)) * SR;
        gr.fo = (float) Math.max(0.003, Math.min(0.09, real * 0.3)) * SR;
        if (gr.ns > 4) active.add(gr);
    }

    /** Vult n samples (mono, -1..1). */
    public void render(float[] out, int n) {
        java.util.Arrays.fill(out, 0, n, 0f);
        final double t = clock / (double) SR;
        final float f = speedFrac;
        final boolean mv = moving;
        final float M = Float.isFinite(spacing) ? Math.max(1f, Math.min(10f, spacing)) : 1.5f;   // M < 1 zou de planner laten vastlopen

        // toestandsovergangen
        if (mv && !wasMoving) {
            tStart = t; uitEnd = -1;
            // uitloop afbreken: alleen nog niet gestarte uitloop-korrels weg
            Iterator<Grain> it = active.iterator();
            while (it.hasNext()) if (it.next().start > clock) it.remove();
            double slope = (1 - R0) * accelHint / vmaxMs;
            ta = Math.min(1.5, Math.max(0.4, (R0 - RLOW) / slope));
        }
        if (!mv && wasMoving) {
            // uitloopreeks plannen
            double tt = 0; double r = R0; int j = 0; int k = gi;
            while (3100 * r >= 20) {
                int kk = k % nGrains;
                float g = master * vol(0) * (float) Math.pow(UIT_VOL, j + 1);
                long st = clock + (long) (tt * SR);
                addGrain(st, kk, r, g, true);
                double real = Math.min((bnd[kk + 1] - bnd[kk]) / (double) SR / r, CAP);
                tt += real * M; r *= Q; j++; k++;
            }
            uitT0 = t; uitEnd = t + tt;
        }
        wasMoving = mv;

        // afspeelsnelheid en volume voor dit blok
        double r; float g;
        if (mv) {
            double u = (t - tStart) / ta;
            if (u < 1) r = R0 * Math.pow(RLOW / R0, Math.pow(1 - u, 1.6)) + (1 - R0) * f;
            else r = R0 + (1 - R0) * f;
            g = master * vol(f) * (float) Math.pow(Math.min(1, u), 1.3);
        } else {
            r = R0;
            g = 0;
            if (uitEnd > 0 && t < uitEnd) g = master * vol(0) * (float) Math.max(0, 1 - (t - uitT0) / (uitEnd - uitT0)) * 0.6f;
        }

        if (!(r > 0.001) || !Double.isFinite(r)) r = R0;                       // veiligheidsnet
        if (!Float.isFinite(g)) g = 0;
        // zoem
        float zg = g * Math.max(0f, Math.min(1f, zoemLevel));
        // afspeelsnelheid binnen het blok glijdend van vorige naar nieuwe waarde (geen knikjes)
        double r0 = rPrev < 0 ? r : rPrev, zp = zpos;
        for (int i = 0; i < n; i++) {
            double ri = r0 + (r - r0) * i / n;
            if (zg > 0 || zgPrev > 0) {
                float gg = zgPrev + (zg - zgPrev) * i / n;
                out[i] += interp(zoem, zp, L) * gg;
            }
            zp += ri;
        }
        zgPrev = zg; rPrev = r;
        zpos = zp % L;

        // bluups synchroon met de bandpositie
        if (mv) {
            double tauNew = tau + r * n;
            int guard = 0;
            while (guard++ < 64) {                                                // max 64 bluups per blok: nooit eindeloos
                int c = gi / nGrains, k = gi % nGrains;
                double p = ((double) c * L + bnd[k]) * M;
                if (p > tauNew) break;
                if (p >= tau) addGrain(clock + (long) ((p - tau) / r), k, r, g, false);
                gi++;
            }
            tau = tauNew;
        }

        if (gi > 1_000_000_000) { gi %= nGrains; tau = 0; }                      // overloop voorkomen bij dagenlang draaien
        if (active.size() > 256) active.subList(0, active.size() - 256).clear();
        // actieve korrels mengen
        Iterator<Grain> it = active.iterator();
        while (it.hasNext()) {
            Grain gr = it.next();
            long rel0 = clock - gr.start;
            if (rel0 >= gr.ns) { it.remove(); continue; }
            for (int i = 0; i < n; i++) {
                long idx = rel0 + i;
                if (idx < 0) continue;
                if (idx >= gr.ns) break;
                float env = Math.min(1f, idx / gr.fi) * Math.min(1f, (gr.ns - idx) / gr.fo);
                out[i] += interp(bluup, gr.a + gr.r * idx, L) * env * gr.g;
            }
        }

        // filter (high-pass + low-pass, elk 2x biquad = 24 dB/octaaf) + volume + zachte begrenzer
        float vo = volume;
        for (int i = 0; i < n; i++) {
            float x = out[i];
            for (Biquad q : hp) x = q.run(x);
            for (Biquad q : lp) x = q.run(x);
            x *= vo;
            out[i] = Float.isFinite(x) ? (float) Math.tanh(x) : 0f;
        }
        clock += n;
    }

    // ---- filters ----
    private static final class Biquad {
        double b0, b1, b2, a1, a2, z1, z2;
        void set(boolean high, double f) {
            double w = 2 * Math.PI * f / SR, cs = Math.cos(w), al = Math.sin(w) / (2 * 0.7071), a0 = 1 + al;
            if (high) { b0 = (1 + cs) / 2; b1 = -(1 + cs); b2 = (1 + cs) / 2; }
            else { b0 = (1 - cs) / 2; b1 = 1 - cs; b2 = (1 - cs) / 2; }
            b0 /= a0; b1 /= a0; b2 /= a0; a1 = -2 * cs / a0; a2 = (1 - al) / a0;
        }
        float run(float x) { double y = b0 * x + z1; z1 = b1 * x - a1 * y + z2; z2 = b2 * x - a2 * y; if (!Double.isFinite(y)) { z1 = z2 = 0; return 0f; } return (float) y; }
    }
    private final Biquad[] hp = {new Biquad(), new Biquad()}, lp = {new Biquad(), new Biquad()};
    { setFilter(40, 2500); }
    /** Comfort-filter: hpHz (laag afkappen), lpHz (hoog afkappen). */
    public synchronized void setFilter(double hpHz, double lpHz) {
        for (Biquad q : hp) q.set(true, Math.max(10, hpHz));
        for (Biquad q : lp) q.set(false, Math.min(18000, lpHz));
    }

    /** Leest een 16-bit mono PCM WAV naar floats. */
    public static float[] readWav(java.io.InputStream in) throws java.io.IOException {
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(); byte[] buf = new byte[8192]; int nr;
        while ((nr = in.read(buf)) > 0) bo.write(buf, 0, nr);
        in.close(); byte[] all = bo.toByteArray();
        int p = 12, dataOff = -1, dataLen = 0;
        while (p + 8 <= all.length) {
            String id = new String(all, p, 4, java.nio.charset.StandardCharsets.US_ASCII);
            int len = (all[p + 4] & 0xff) | (all[p + 5] & 0xff) << 8 | (all[p + 6] & 0xff) << 16 | (all[p + 7] & 0xff) << 24;
            if (id.equals("data")) { dataOff = p + 8; dataLen = Math.min(len, all.length - dataOff); break; }
            p += 8 + len + (len & 1);
        }
        if (dataOff < 0) throw new java.io.IOException("geen data-chunk in WAV");
        float[] s = new float[dataLen / 2];
        for (int i = 0; i < s.length; i++) {
            short v = (short) ((all[dataOff + 2 * i] & 0xff) | (all[dataOff + 2 * i + 1] << 8));
            s[i] = v / 32768f;
        }
        return s;
    }

    /** Leest een stereo WAV (links = zoem, rechts = bluups). Geeft {zoem, bluup} terug. */
    public static float[][] readStereoWav(byte[] all) throws java.io.IOException {
        int p = 12, dataOff = -1, dataLen = 0, ch = 1;
        while (p + 8 <= all.length) {
            String id = new String(all, p, 4, java.nio.charset.StandardCharsets.US_ASCII);
            int len = (all[p + 4] & 0xff) | (all[p + 5] & 0xff) << 8 | (all[p + 6] & 0xff) << 16 | (all[p + 7] & 0xff) << 24;
            if (id.equals("fmt ")) ch = (all[p + 10] & 0xff) | (all[p + 11] & 0xff) << 8;
            if (id.equals("data")) { dataOff = p + 8; dataLen = Math.min(len, all.length - dataOff); break; }
            if (len < 0) break;
            p += 8 + len + (len & 1);
        }
        if (dataOff < 0 || ch < 1 || ch > 2) throw new java.io.IOException("onbekend WAV-formaat");
        int n = dataLen / (2 * ch);
        if (n < 4000) throw new java.io.IOException("geluid te kort");
        float[] a = new float[n], b = new float[n];
        for (int i = 0; i < n; i++) {
            int o = dataOff + 2 * ch * i;
            a[i] = (short) ((all[o] & 0xff) | (all[o + 1] << 8)) / 32768f;
            b[i] = ch == 2 ? (short) ((all[o + 2] & 0xff) | (all[o + 3] << 8)) / 32768f : a[i];
        }
        return new float[][]{a, b};
    }

    /** Zoekt 12 bluup-grenzen: de stilste plek in de bluup-lus rond elke 1/12e. */
    public static int[] detectBounds(float[] bl) {
        int L = bl.length, w = Math.max(1, BluupSynth.SR / 300);
        float[] env = new float[L]; double acc = 0;
        for (int i = 0; i < L + w; i++) { acc += Math.abs(bl[i % L]); if (i >= w) acc -= Math.abs(bl[(i - w) % L]); env[i % L] = (float) (acc / w); }
        int[] bnd = new int[12]; int span = L / 30;
        for (int k = 0; k < 12; k++) {
            int c = (int) ((long) k * L / 12), best = c; float min = Float.MAX_VALUE;
            for (int j = c - span; j <= c + span; j++) { int jj = ((j % L) + L) % L; if (env[jj] < min) { min = env[jj]; best = jj; } }
            bnd[k] = best;
        }
        int sh = bnd[0];
        for (int k = 0; k < 12; k++) bnd[k] = ((bnd[k] - sh) % L + L) % L;   // eerste grens op 0 (lus is rond)
        java.util.Arrays.sort(bnd);
        return bnd;
    }

    /** Grenzen van de 12 bluups in de lus (samples). */
    public static final int[] GRAIN_BOUNDS = {0, 1764, 3528, 5292, 7056, 8820, 10584, 12348, 14112, 15876, 17640, 19404};
}
