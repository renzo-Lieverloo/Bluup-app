package nl.welcomenewworld.jetsonbox;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.IntentFilter;
import android.provider.MediaStore;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;

/**
 * Voorgrondservice: draait door met het scherm uit.
 * Modus ACTIVE = geluid volgt de snelheid. Modus CALIBRATE = ijkrit opnemen, zonder motorgeluid.
 */
public class JetsonService extends Service implements SensorEventListener, LocationListener {
    public static final String ACTION_ACTIVE = "nl.welcomenewworld.jetsonbox.ACTIVE";
    public static final String ACTION_CALIBRATE = "nl.welcomenewworld.jetsonbox.CALIBRATE";
    public static final String ACTION_STOP = "nl.welcomenewworld.jetsonbox.STOP";
    private static final String CH = "bluup";
    private static final int NID = 26;

    // gedeelde status voor het scherm (zelfde proces)
    public static volatile boolean running = false;
    public static volatile String mode = "uit";
    public static volatile double speedKmh = 0, gpsKmh = -1;
    public static volatile boolean moving = false, gpsOk = false, forwardKnown = false;
    public static volatile Calibrator calibrator = null;

    private SensorManager sm;
    private LocationManager lm;
    private PowerManager.WakeLock wl;
    private AudioManager am;
    private AudioFocusRequest afr;
    private SpeedFusion fusion;
    private BluupSynth synth;
    private Thread audioThread;
    private volatile boolean audioRun = false;
    private long lastCtrlNs = 0;
    private volatile long lastSensorNs = 0;
    private Location prevLoc = null;      // tijdbasis van de sensoren, ook gebruikt voor GPS
    private HandlerThread sensorThread;
    private float vmax = 25f;
    private String prof = "efiets_";
    public static volatile boolean sleeping = false;
    public static volatile float reactie = 0.7f;      // live instelbaar vanuit de app
    private float reactieApplied = -1f; private double btLead = 0;
    private StringBuilder log; private long logT0 = 0, lastLogNs = 0; private String logName;
    private final BroadcastReceiver noisy = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { if (synth != null) synth.volume = 0.6f; }   // Bluetooth weg -> zachter op de telefoonspeaker
    };

    /** Laadt de geluidsmotor: eigen geluid (als gekozen) of het standaardgeluid. */
    public static BluupSynth loadSynth(Context c) throws java.io.IOException {
        java.io.File f = new java.io.File(c.getFilesDir(), "eigen_geluid.wav");
        if (f.exists()) {
            try {
                byte[] all = new byte[(int) f.length()];
                java.io.FileInputStream in = new java.io.FileInputStream(f);
                int off = 0, n; while (off < all.length && (n = in.read(all, off, all.length - off)) > 0) off += n;
                in.close();
                return BluupSynth.fromStereo(all);
            } catch (Exception e) { /* kapot bestand: terug naar standaard */ }
        }
        return new BluupSynth(BluupSynth.readWav(c.getResources().openRawResource(R.raw.zoem_loop)),
                BluupSynth.readWav(c.getResources().openRawResource(R.raw.bluup_loop)), BluupSynth.GRAIN_BOUNDS);
    }

    public static void start(Context c, String action) {
        Intent i = new Intent(c, JetsonService.class).setAction(action);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_ACTIVE : intent.getAction();
        if (ACTION_STOP.equals(action)) { stopAll(); return START_NOT_STICKY; }

        SharedPreferences sp = getSharedPreferences("bluup", MODE_PRIVATE);
        prof = sp.getString("voertuig", "efiets") + "_";
        vmax = sp.getFloat(prof + "vmax", sp.getFloat("vmax", 25f));
        String newMode = ACTION_CALIBRATE.equals(action) ? "ijken" : "aan";

        try { startForegroundCompat(newMode); }
        catch (Exception e) { stopSelf(); return START_NOT_STICKY; }   // bijv. geen locatietoestemming
        if (!running) startSensors(sp);
        running = true;
        mode = newMode;

        if ("ijken".equals(mode)) {
            calibrator = new Calibrator();
            fusion.resetForward();
            stopAudio();
        } else {
            calibrator = null;
            startAudio(sp);
        }
        return START_STICKY;
    }

    private void startForegroundCompat(String m) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH, "JetZons Bluupapp", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Laat zien dat de bluup-mobiel aan staat");
            nm.createNotificationChannel(ch);
        }
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, JetsonService.class).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_media_play)
         .setContentTitle("ijken".equals(m) ? "JetZons Bluupapp kalibreert" : "JetZons Bluupapp staat aan")
         .setContentText("ijken".equals(m) ? "Volg de stappen in de app" : "Vmax " + Math.round(vmax) + " km/u · geluid volgt je snelheid")
         .setOngoing(true)
         .setContentIntent(open)
         .addAction(new Notification.Action.Builder(null, "Uitschakelen", stop).build());
        Notification n = b.build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        else startForeground(NID, n);
    }

    private void startSensors(SharedPreferences sp) {
        fusion = new SpeedFusion();
        double[] g = readVec(sp, prof + "g"), f = readVec(sp, prof + "f");
        fusion.setMount(g, f);

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "bluup:rit");
        wl.acquire(6 * 60 * 60 * 1000L);

        sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        Sensor acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        Sensor gyr = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        sensorThread = new HandlerThread("bluup-sensoren"); sensorThread.start();
        Handler h = new Handler(sensorThread.getLooper());           // sensoren niet op de UI-thread
        if (acc != null) sm.registerListener(this, acc, 10000, h);   // 100 Hz
        if (gyr != null) sm.registerListener(this, gyr, 10000, h);

        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500L, 0f, this, Looper.getMainLooper());
        } catch (SecurityException e) {
            gpsOk = false;
        }
    }

    private void startAudio(SharedPreferences sp) {
        if (audioRun) return;
        try {
            synth = loadSynth(this);   // altijd vers: eigen geluid kan gewijzigd zijn
        } catch (Exception e) { return; }
        synth.zoemLevel = sp.getFloat("zoem", 0.35f);
        synth.spacing = sp.getFloat("spacing", 1.5f);
        boolean phone = "telefoon".equals(sp.getString("speaker", "telefoon"));
        if (phone) synth.setFilter(180, 3000); else synth.setFilter(40, 2500);
        reactie = sp.getFloat("reactie", 0.7f); btLead = phone ? 0 : 0.2; reactieApplied = -1f;   // Bluetooth loopt ~0,2 s achter: iets verder vooruitkijken
        synth.volume = 1f;
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(noisy, new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY), Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(noisy, new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
        log = new StringBuilder("t_s,snelheid_kmh,gps_kmh,rijdt,versnelling,stil_s,vooruit_bekend,slaapstand,geluid_kmh,gps_genegeerd\n");
        logT0 = SystemClock.elapsedRealtimeNanos();
        logName = "bluup_rit_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".csv";

        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        AudioAttributes aa = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        if (Build.VERSION.SDK_INT >= 26) {
            afr = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(aa)
                    .setOnAudioFocusChangeListener(fc -> {
                        if (synth == null) return;
                        if (fc == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT || fc == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) synth.volume = 0.25f;
                        else if (fc == AudioManager.AUDIOFOCUS_GAIN) synth.volume = 1f;
                    }).build();
            am.requestAudioFocus(afr);
        }
        int minBuf = AudioTrack.getMinBufferSize(BluupSynth.SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
        final AudioTrack at = new AudioTrack.Builder()
                .setAudioAttributes(aa)
                .setAudioFormat(new AudioFormat.Builder().setSampleRate(BluupSynth.SR).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(Math.max(minBuf, 4 * 441 * 2))
                .setTransferMode(AudioTrack.MODE_STREAM).build();
        audioRun = true;
        audioThread = new Thread(() -> {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO);
            float[] f = new float[441]; short[] s = new short[441];
            if (at.getState() != AudioTrack.STATE_INITIALIZED) { audioRun = false; at.release(); return; }
            try { at.play(); } catch (IllegalStateException ex) { audioRun = false; at.release(); return; }
            boolean paused = false;
            while (audioRun) {
                if (sleeping) { if (!paused) { at.pause(); paused = true; } try { Thread.sleep(200); } catch (InterruptedException ignored) {} continue; }
                if (paused) { at.play(); paused = false; }
                synth.render(f, f.length);
                for (int i = 0; i < f.length; i++) s[i] = (short) (Math.max(-1f, Math.min(1f, f[i])) * 32767);
                at.write(s, 0, s.length);
            }
            at.stop(); at.release();
        }, "bluup-audio");
        audioThread.start();
    }

    private void stopAudio() {
        if (audioRun) { try { unregisterReceiver(noisy); } catch (Exception ignored) {} saveLog(); }
        audioRun = false;
        if (audioThread != null) { try { audioThread.join(500); } catch (InterruptedException ignored) {} audioThread = null; }
        if (am != null && afr != null && Build.VERSION.SDK_INT >= 26) am.abandonAudioFocusRequest(afr);
    }

    // ---------------- sensoren ----------------
    @Override
    public synchronized void onSensorChanged(SensorEvent e) {
        if (fusion == null) return;
        lastSensorNs = e.timestamp;
        if (e.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            fusion.onAccel(e.timestamp, e.values[0], e.values[1], e.values[2]);
            if (e.timestamp - lastCtrlNs >= 10_000_000L) {   // 100x per seconde
                double dt = lastCtrlNs == 0 ? 0.01 : (e.timestamp - lastCtrlNs) * 1e-9;
                lastCtrlNs = e.timestamp;
                if (reactie != reactieApplied) { reactieApplied = reactie; fusion.setResponse(reactie, btLead); }
                speedKmh = fusion.speed() * 3.6;
                moving = fusion.isMoving();
                forwardKnown = fusion.hasForward();
                gpsOk = fusion.gpsFresh(e.timestamp);
                // slaapstand na 5 min stilstand; wakker zodra je weer beweegt
                boolean wake = fusion.sensorActive() || fusion.speed() > 0.6;
                if (!sleeping && fusion.stillSeconds() > 300 && "aan".equals(mode)) setSleep(true);
                else if (sleeping && wake) setSleep(false);
                if (synth != null && audioRun) synth.setState((float) fusion.smoothSpeed(), moving, (float) Math.abs(fusion.accel()), vmax);
                if (log != null && e.timestamp - lastLogNs >= 100_000_000L && log.length() < 8_000_000) {
                    lastLogNs = e.timestamp;
                    log.append(String.format(Locale.US, "%.1f,%.2f,%.2f,%d,%.3f,%.1f,%d,%d,%.2f,%d%n", (e.timestamp - logT0) * 1e-9, speedKmh, gpsKmh, moving ? 1 : 0, fusion.accel(), fusion.stillSeconds(), forwardKnown ? 1 : 0, sleeping ? 1 : 0, fusion.smoothSpeed() * 3.6, fusion.gpsRejected));
                }
                Calibrator c = calibrator;
                if (c != null && c.step >= 0 && c.step < 4) {
                    c.update(dt, fusion.speed(), fusion.accel(), !moving, gpsOk);
                    if (c.step == 4) saveCalibration(c);
                }
            }
        } else if (e.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            fusion.onGyro(e.timestamp, e.values[0], e.values[1], e.values[2]);
        }
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    @Override
    public synchronized void onLocationChanged(Location loc) {
        if (fusion == null) return;
        // sensortijd en GPS-tijd hebben op sommige toestellen een andere basis: gebruik de laatste sensortijd
        long ns = lastSensorNs != 0 ? lastSensorNs : SystemClock.elapsedRealtimeNanos();
        double sp, acc = -1;
        if (loc.hasSpeed()) {
            sp = loc.getSpeed();
            if (loc.hasSpeedAccuracy()) acc = loc.getSpeedAccuracyMetersPerSecond();
        } else if (prevLoc != null && loc.hasAccuracy() && loc.getAccuracy() < 12 && prevLoc.hasAccuracy() && prevLoc.getAccuracy() < 12) {
            double dts = (loc.getElapsedRealtimeNanos() - prevLoc.getElapsedRealtimeNanos()) * 1e-9;   // geen snelheid meegeleverd: uit positie
            if (dts < 0.9 || dts > 5) { if (dts > 5) prevLoc = loc; return; }
            sp = loc.distanceTo(prevLoc) / dts;
        } else { prevLoc = loc; return; }
        prevLoc = loc;
        if (!loc.hasAccuracy() || loc.getAccuracy() < 60) {
            fusion.onGps(ns, sp, acc);
            gpsKmh = sp * 3.6;
        }
    }
    @Override public void onStatusChanged(String p, int s, Bundle b) {}
    @Override public void onProviderEnabled(String p) {}
    @Override public void onProviderDisabled(String p) { gpsOk = false; }

    private void setSleep(boolean on) {
        sleeping = on;
        try {
            lm.removeUpdates(this);
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, on ? 5000L : 500L, 0f, this, Looper.getMainLooper());
        } catch (Exception ignored) {}
    }

    private synchronized void saveLog() {
        if (log == null || log.length() < 200) { log = null; return; }
        try {
            byte[] data = log.toString().getBytes("UTF-8");
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, logName);
                cv.put(MediaStore.Downloads.MIME_TYPE, "text/csv");
                cv.put(MediaStore.Downloads.RELATIVE_PATH, "Download/JetZon BluupBox");
                android.net.Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (u != null) { OutputStream os = getContentResolver().openOutputStream(u); if (os != null) { os.write(data); os.close(); } }
            } else {
                java.io.File d = getExternalFilesDir("ritten");
                if (d != null) { java.io.FileOutputStream fo = new java.io.FileOutputStream(new java.io.File(d, logName)); fo.write(data); fo.close(); }
            }
        } catch (Exception ignored) {}
        log = null;
    }

    private void saveCalibration(Calibrator c) {
        SharedPreferences.Editor ed = getSharedPreferences("bluup", MODE_PRIVATE).edit();
        ed.putFloat(prof + "vmaxMeasured", (float) c.vmaxKmh).putFloat(prof + "accel", (float) c.accel).putFloat(prof + "decel", (float) c.decel);
        writeVec(ed, prof + "g", fusion.getGravity());
        writeVec(ed, prof + "f", fusion.getForward());
        ed.apply();
    }

    private static double[] readVec(SharedPreferences sp, String k) {
        if (!sp.contains(k + "0")) return null;
        return new double[]{sp.getFloat(k + "0", 0), sp.getFloat(k + "1", 0), sp.getFloat(k + "2", 0)};
    }
    private static void writeVec(SharedPreferences.Editor ed, String k, double[] v) {
        if (v == null) return;
        for (int i = 0; i < 3; i++) ed.putFloat(k + i, (float) v[i]);
    }

    private void stopAll() {
        if (!running && sm == null) { stopSelf(); return; }
        stopAudio();
        if (sm != null) { sm.unregisterListener(this); sm = null; }
        if (sensorThread != null) { sensorThread.quitSafely(); sensorThread = null; }
        if (lm != null) try { lm.removeUpdates(this); } catch (Exception ignored) {}
        if (wl != null && wl.isHeld()) wl.release();
        running = false; mode = "uit"; moving = false; speedKmh = 0;
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE); else stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() { if (running) stopAll(); super.onDestroy(); }
}
