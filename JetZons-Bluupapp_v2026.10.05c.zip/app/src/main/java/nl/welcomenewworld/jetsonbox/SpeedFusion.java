package nl.welcomenewworld.jetsonbox;

/**
 * Snelheidsschatting uit ruwe versnellingsmeter + gyro + GPS (puur Java).
 * Gebaseerd op de ritanalyse van 4 okt 2026:
 *  - ruwe versnelling minus zwaartekracht (niet de Android "linear acceleration", die meet ~37% te weinig)
 *  - vooruit-as wordt automatisch geleerd door de versnelling te vergelijken met GPS
 *  - fusie: v += (a - b) dt; bij elke GPS-meting corrigeren (v en bias b)
 *  - stilstand: sensor-stil (lin < 1,2 m/s2 rms en gyro < 0,15 rad/s rms) of GPS < 1,5 km/u
 */
public final class SpeedFusion {
    // ---- instelbare constanten ----
    public static final double KV = 0.7, KB = 0.15;          // GPS-correctie snelheid / bias
    public static final double LIN_STILL = 1.2, GYR_STILL = 0.15;
    public static final double GPS_STILL = 1.5 / 3.6, MOVE_ON = 2.0 / 3.6;
    public static final double LP_HZ = 2.0;
    public static final double SENSOR_STILL_MAX_V = 6.0 / 3.6;   // "trillingsvrij" telt alleen als stilstand onder deze snelheid
    public static final double GPS_HOLD_S = 15, GPS_DECAY_TAU = 90;  // GPS weg: 15 s vasthouden, daarna heel langzaam wegzakken
    public static final double SLEW_UP = 6.0, SLEW_DOWN = 10.0;
    private double outTau = 0.05;
    public static final double GPS_LAG = 0.8;     // s: GPS-snelheid loopt zoveel achter (ritanalyse 4 okt: 0,75 s)
    private double lead = 0.35;                   // s: vooruitkijken op de versnelling = direct "gaspedaalgevoel" // uitgaande snelheid voor het geluid: max m/s2 + afvlakking
    public static final double GPS_MAX_JUMP = 9.0;              // m/s2: grotere sprong tussen twee GPS-metingen = storing

    // ---- geleerde montagestand (telefoon-assen) ----
    private double[] g0 = null;          // zwaartekracht in rust
    private double[] fwd = null;         // vooruit (eenheidsvector)
    private int g0n = 0;

    // ---- toestand ----
    private double v = 0, b = 0, aF = 0;
    private double linMs = 0, gyrMs = 0;
    private long lastAccNs = 0, lastGyrNs = 0;
    private double gpsSpeed = -1, gpsPrev = -1;
    private long gpsNs = 0, gpsPrevNs = 0;
    private boolean moving = false;
    private double stillFor = 0;
    private double[] lastLin = new double[3];
    private double sensorMoveFor = 0;
    public int mountChanged = 0;
    private double[] gS = null;
    private final double[] vHist = new double[256]; private final long[] tHist = new long[256]; private int hIdx = 0;
    private double vOut = 0; private int gpsRejects = 0; public int gpsRejected = 0;

    // ---- vooruit-as leren (regressie GPS-versnelling op horizontale sensorversnelling) ----
    private double s1 = 0, s2 = 0; private int sn = 0;           // som horizontale componenten in huidig GPS-interval
    private double prevM1 = Double.NaN, prevM2 = Double.NaN;      // gemiddelde vorig interval (GPS loopt ~1 s achter)
    private double xx11 = 0, xx12 = 0, xx22 = 0, xy1 = 0, xy2 = 0, sw = 0, sm1 = 0, sm2 = 0, sag = 0; private int nReg = 0;
    private double[] e1, e2;

    public SpeedFusion() {}

    public void setMount(double[] gravity, double[] forward) {
        if (gravity != null) { g0 = gravity.clone(); g0n = 100; basis(); }
        if (forward != null) fwd = forward.clone();
    }
    public double[] getGravity() { return g0 == null ? null : g0.clone(); }
    public double[] getForward() { return fwd == null ? null : fwd.clone(); }
    public boolean hasForward() { return fwd != null; }
    public double stillSeconds() { return stillFor; }
    public boolean sensorActive() { return sensorMoveFor > 1.0; }
    public void resetForward() { fwd = null; xx11 = xx12 = xx22 = xy1 = xy2 = sw = sm1 = sm2 = sag = 0; nReg = 0; prevM1 = Double.NaN; }

    public double speed() { return v; }
    /** Afgevlakte snelheid voor het geluid: geen sprongen bij GPS-storingen. */
    public double smoothSpeed() { return vOut; }
    /** Vooruitkijktijd in s (meer bij Bluetooth, dat zelf ~0,2 s achterloopt). */
    public void setLead(double s) { if (Double.isFinite(s)) lead = Math.max(0, Math.min(1.0, s)); }
    /** Reactie-instelling 0 (rustig) .. 1 (direct): vooruitkijktijd en afvlakking. extraLead = Bluetooth-vertraging. */
    public void setResponse(double r, double extraLead) {
        if (!Double.isFinite(r)) r = 0.7;
        r = Math.max(0, Math.min(1, r));
        setLead(0.5 * r + extraLead);
        outTau = 0.03 + 0.6 * (1 - r) * (1 - r);
    }
    public double accel() { return aF - b; }
    public boolean isMoving() { return moving; }
    public boolean gpsFresh(long nowNs) { return gpsSpeed >= 0 && nowNs - gpsNs < 2_500_000_000L; }
    public double gpsSpeed() { return gpsSpeed; }

    private void basis() {
        double n = Math.sqrt(dot(g0, g0)); if (n < 1e-3) return; double[] up = {g0[0] / n, g0[1] / n, g0[2] / n};
        double[] ref = Math.abs(up[2]) < 0.9 ? new double[]{0, 0, 1} : new double[]{1, 0, 0};
        e1 = norm(cross(up, ref)); e2 = cross(up, e1);
    }

    /** Ruwe versnellingsmeter (m/s2, telefoon-assen), tijd in ns. */
    public void onAccel(long tNs, double ax, double ay, double az) {
        if (!(Double.isFinite(ax) && Double.isFinite(ay) && Double.isFinite(az))) return;   // kapotte meting overslaan
        double dt = lastAccNs == 0 ? 0.01 : (tNs - lastAccNs) * 1e-9;
        if (!(dt > 0)) return;                    // tijd liep terug of dubbel: overslaan
        dt = Math.min(0.1, dt);
        lastAccNs = tNs;
        double[] a = {ax, ay, az};
        if (dot(a, a) < 1e-4) return;             // nulvector: geen bruikbare meting
        // zwaartekracht: in het begin en bij stilstand bijwerken
        boolean stillNow = stillFor > 0.5 || (!moving && g0n < 100);
        if (g0 == null) { g0 = a.clone(); g0n = 1; basis(); }
        else if (stillNow) {
            double k = g0n < 100 ? 1.0 / (++g0n) : dt / 8.0;   // traag bijleren: wegrijden mag de zwaartekracht niet scheeftrekken
            for (int i = 0; i < 3; i++) g0[i] += (a[i] - g0[i]) * k;
            basis();
        }
        double[] lin = {a[0] - g0[0], a[1] - g0[1], a[2] - g0[2]};
        lastLin = lin;
        double tau = 1.0, k = dt / (tau + dt);
        linMs += (dot(lin, lin) - linMs) * k;

        // horizontale componenten voor het leren van de vooruit-as
        s1 += dot(lin, e1); s2 += dot(lin, e2); sn++;

        // vooruit-versnelling, laagdoorlaat 2 Hz
        double raw = fwd == null ? 0 : dot(lin, fwd);
        raw = Math.max(-6, Math.min(6, raw));                       // schokfilter: klinkers/drempels
        double rc = 1 / (2 * Math.PI * LP_HZ);
        aF += (raw - aF) * dt / (rc + dt);

        // stilstand
        boolean sensorStill = Math.sqrt(linMs) < LIN_STILL && Math.sqrt(gyrMs) < GYR_STILL;
        // In een auto is de telefoon op een gladde weg bijna trillingsvrij. Dat mag NIET als stilstand tellen bij snelheid:
        // met verse GPS beslist de GPS, zonder GPS telt "trillingsvrij" alleen als je al bijna stilstond.
        boolean still;
        if (gpsFresh(tNs)) still = gpsSpeed < GPS_STILL || (sensorStill && gpsSpeed < 1.0 && v < SENSOR_STILL_MAX_V);
        else still = sensorStill && v < SENSOR_STILL_MAX_V;
        stillFor = still ? stillFor + dt : 0;

        // houder verschoven? zwaartekracht wijkt in stilstand > 15 graden af -> opnieuw leren
        if (gS == null) gS = a.clone(); else for (int i = 0; i < 3; i++) gS[i] += (a[i] - gS[i]) * dt / (0.5 + dt);
        if (stillFor > 1.5 && g0n >= 100) {
            double c = dot(gS, g0) / Math.sqrt(dot(gS, gS) * dot(g0, g0));
            if (c < Math.cos(Math.toRadians(20))) { g0 = gS.clone(); g0n = 1; basis(); resetForward(); mountChanged++; }
        }
        // beweging uit sensoren (vooral nodig voordat GPS er is)
        boolean sensorMove = Math.sqrt(linMs) > 2.0 || Math.sqrt(gyrMs) > 0.25;
        sensorMoveFor = sensorMove ? sensorMoveFor + dt : 0;

        // integreren
        if (fwd != null) {
            double an = aF - b;
            if (!gpsFresh(tNs) && Math.abs(an) < 0.25) an = 0;      // zonder GPS: ruis niet optellen (geen drift in tunnels)
            v += an * dt;
        }
        // GPS langer dan 5 s weg: snelheid langzaam laten wegzakken (geen eindeloze drift)
        if (!gpsFresh(tNs) && gpsNs != 0 && tNs - gpsNs > (long) (GPS_HOLD_S * 1e9)) v *= Math.exp(-dt / GPS_DECAY_TAU);
        if (stillFor > 0.7) { v = 0; moving = false; }
        if (v < 0 || !Double.isFinite(v)) v = 0;
        if (!Double.isFinite(b)) b = 0;
        if (!Double.isFinite(aF)) aF = 0;
        v = Math.min(v, 150);
        vHist[hIdx] = v; tHist[hIdx] = tNs; hIdx = (hIdx + 1) & 255;
        // uitgaande snelheid: snelheid + vooruitkijken op de versnelling (lead), begrensd en heel licht afgevlakt
        double ld = fwd != null && v > MOVE_ON ? lead * Math.max(-4, Math.min(4, aF - b)) : 0;
        double target = moving || v > MOVE_ON ? Math.max(0, v + ld) : 0, d = target - vOut, lim = (d > 0 ? SLEW_UP : SLEW_DOWN) * dt;
        if (stillFor > 0.7) vOut += (0 - vOut) * Math.min(1, dt / 0.15);
        else vOut += Math.max(-lim, Math.min(lim, d * Math.min(1, dt / outTau)));
        if (!Double.isFinite(vOut) || vOut < 0) vOut = 0;
        if (!moving && (v > MOVE_ON || (gpsFresh(tNs) && gpsSpeed > MOVE_ON * 1.25) || (gpsNs == 0 && sensorMoveFor > 1.5))) moving = true;
    }

    /** Gyroscoop (rad/s). */
    public void onGyro(long tNs, double gx, double gy, double gz) {
        if (!(Double.isFinite(gx) && Double.isFinite(gy) && Double.isFinite(gz))) return;
        double dt = lastGyrNs == 0 ? 0.01 : (tNs - lastGyrNs) * 1e-9;
        if (!(dt > 0)) return;
        dt = Math.min(0.1, dt);
        lastGyrNs = tNs;
        double k = dt / (1.0 + dt);
        gyrMs += (gx * gx + gy * gy + gz * gz - gyrMs) * k;
    }

    /** GPS-snelheid (m/s). */
    public void onGps(long tNs, double speedMs) { onGps(tNs, speedMs, -1); }
    /** GPS-snelheid met nauwkeurigheid (m/s, -1 = onbekend). Slechte of springende metingen worden genegeerd. */
    public void onGps(long tNs, double speedMs, double accMs) {
        if (!(speedMs >= 0) || speedMs > 150 || !Double.isFinite(speedMs)) return;   // > 540 km/u = onzin
        if (accMs > 2.5) { gpsRejected++; return; }                                  // onnauwkeurig (tunnel, gebouwen, slechte fix)
        if (gpsFresh(tNs) && gpsSpeed >= 0) {
            double dtj = Math.max(0.3, (tNs - gpsNs) * 1e-9);
            if (Math.abs(speedMs - gpsSpeed) / dtj > GPS_MAX_JUMP && Math.abs(speedMs - v) > 3 && ++gpsRejects < 3) { gpsRejected++; return; }
        }
        gpsRejects = 0;
        gpsPrev = gpsSpeed; gpsPrevNs = gpsNs;
        gpsSpeed = speedMs; gpsNs = tNs;

        // vooruit-as leren
        if (sn > 0) {
            double m1 = s1 / sn, m2 = s2 / sn; s1 = s2 = 0; sn = 0;
            if (gpsPrev >= 0 && !Double.isNaN(prevM1)) {
                double dtg = (gpsNs - gpsPrevNs) * 1e-9;
                if (dtg > 0.3 && dtg < 3) {
                    double ag = (gpsSpeed - gpsPrev) / dtg;
                    if (gpsSpeed > 1.0 || gpsPrev > 1.0) {
                        double fg = 0.985; xx11 *= fg; xx12 *= fg; xx22 *= fg; xy1 *= fg; xy2 *= fg; sw *= fg; sm1 *= fg; sm2 *= fg; sag *= fg;
                        sw += 1; sm1 += prevM1; sm2 += prevM2; sag += ag;   // gemiddelden: vaste afwijkingen mogen niet meetellen
                        xx11 += prevM1 * prevM1; xx12 += prevM1 * prevM2; xx22 += prevM2 * prevM2;
                        xy1 += prevM1 * ag; xy2 += prevM2 * ag; nReg++;
                        if (nReg >= 12 && nReg % 3 == 0) learnForward();
                    }
                }
            }
            prevM1 = m1; prevM2 = m2;
        }

        // snelheidscorrectie: vergelijk de GPS met wat wij 0,8 s geleden dachten (GPS loopt achter),
        // anders trekt de GPS de snelheid steeds terug naar het verleden en voelt alles traag
        double e = gpsSpeed - vAt(tNs - (long) (GPS_LAG * 1e9));
        v += KV * e;
        if (fwd != null) b -= KB * e;
        b = Math.max(-1.0, Math.min(1.0, b));
        if (v < 0) v = 0;
    }

    private double vAt(long t) {
        for (int k = 1; k <= 255; k++) { int i = (hIdx - k) & 255; if (tHist[i] == 0) break; if (tHist[i] <= t) return vHist[i]; }
        return v;
    }

    private void learnForward() {
        if (sw < 1) return;
        double m1 = sm1 / sw, m2 = sm2 / sw, my = sag / sw;           // gecentreerde regressie (met constante term)
        double c11 = xx11 - sw * m1 * m1, c12 = xx12 - sw * m1 * m2, c22 = xx22 - sw * m2 * m2;
        double y1 = xy1 - sw * m1 * my, y2 = xy2 - sw * m2 * my;
        double lam = 0.05 * sw; c11 += lam; c22 += lam;                 // ridge: ruis op een as zonder signaal niet opblazen
        double det = c11 * c22 - c12 * c12;
        if (Math.abs(det) < 1e-6) return;
        double w1 = (c22 * y1 - c12 * y2) / det, w2 = (c11 * y2 - c12 * y1) / det;
        double mag = Math.hypot(w1, w2);
        if (mag < 0.2) return;
        double[] f = {w1 * e1[0] + w2 * e2[0], w1 * e1[1] + w2 * e2[1], w1 * e1[2] + w2 * e2[2]};
        double[] nf = norm(f);
        if (Double.isFinite(nf[0]) && Double.isFinite(nf[1]) && Double.isFinite(nf[2])) fwd = nf;
    }

    private static double dot(double[] a, double[] b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
    private static double[] cross(double[] a, double[] b) { return new double[]{a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]}; }
    private static double[] norm(double[] a) { double n = Math.sqrt(dot(a, a)); return new double[]{a[0] / n, a[1] / n, a[2] / n}; }
}
