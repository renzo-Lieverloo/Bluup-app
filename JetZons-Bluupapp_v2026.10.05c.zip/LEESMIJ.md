# Bluup-mobiel (Android)

Testversie 0.1. Bouwt een APK via GitHub Actions (zie .github/workflows/build.yml) of via Android Studio (Build > Build APK).

- app/src/main/assets/index.html  — de voorkant (startscherm, eerste-opstart, Vmax-schijf, kalibreren, activeren)
- JetsonService.java   — voorgrondservice: sensoren, GPS, geluid, werkt met scherm uit
- SpeedFusion.java     — snelheid uit versnellingsmeter + gyro + GPS (getest op de e-bike-ritten van 4 okt 2026)
- Calibrator.java      — ijkrit: stilstaan, optrekken, 10 s Vmax, remmen
- BluupSynth.java      — geluidsmotor (zoem + bluups, aanloop, uitloop tot onder 20 Hz)
- res/raw/*.wav        — eigen gesynthetiseerd geluid
