package nl.welcomenewworld.jetsonbox;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;

import org.json.JSONObject;

/** Het scherm: de bluup-mobiel-voorkant (HTML in assets) met een brug naar de service. */
public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fileCb;
    private static final int REQ_PERM = 7, REQ_FILE = 8;

    // ---- testgas: de echte geluidsmotor, aangestuurd door de schuif ----
    private BluupSynth testSynth;
    private volatile boolean testRun = false;
    private volatile float testGas = 0f;
    private volatile long testIdleSince = 0;

    private void startTest() {
        if (testRun || JetsonService.running && "aan".equals(JetsonService.mode)) return;   // niet dubbel met een rit
        try {
            if (testSynth == null) testSynth = JetsonService.loadSynth(this);
        } catch (Exception e) { return; }
        SharedPreferences sp = prefs();
        testSynth.zoemLevel = sp.getFloat("zoem", 0.35f);
        testSynth.spacing = sp.getFloat("spacing", 1.5f);
        if ("telefoon".equals(sp.getString("speaker", "telefoon"))) testSynth.setFilter(180, 3000); else testSynth.setFilter(40, 2500);
        testRun = true;
        new Thread(() -> {
            int minBuf = AudioTrack.getMinBufferSize(BluupSynth.SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            AudioTrack at = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(BluupSynth.SR).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(Math.max(minBuf, 4 * 441 * 2)).setTransferMode(AudioTrack.MODE_STREAM).build();
            if (at.getState() != AudioTrack.STATE_INITIALIZED) { testRun = false; at.release(); return; }
            float[] f = new float[441]; short[] s16 = new short[441];
            float vmaxK = prefs().getFloat("vmax", 25f);
            try { at.play(); } catch (IllegalStateException ex) { testRun = false; at.release(); return; }
            while (testRun) {
                float g = testGas;
                testSynth.setState(g * vmaxK / 3.6f, g > 0.02f, 1.5f, vmaxK);
                testSynth.render(f, f.length);
                for (int i = 0; i < f.length; i++) s16[i] = (short) (Math.max(-1f, Math.min(1f, f[i])) * 32767);
                at.write(s16, 0, s16.length);
                // 6 s na loslaten (uitloop voorbij) de testspeler stoppen
                if (g <= 0.001f && System.currentTimeMillis() - testIdleSince > 6000) testRun = false;
            }
            at.stop(); at.release();
        }, "bluup-test").start();
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setAllowFileAccess(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                fileCb = cb;
                String[] acc = p.getAcceptTypes();
                boolean audio = acc != null && acc.length > 0 && acc[0] != null && acc[0].startsWith("audio");
                // kiezer opent direct in Download/JetZon BluupBox (daar zet je je eigen geluid en plaatjes)
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).setType(audio ? "audio/*" : "image/*").addCategory(Intent.CATEGORY_OPENABLE);
                i.putExtra(android.provider.DocumentsContract.EXTRA_INITIAL_URI,
                        Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADownload%2FJetZon%20BluupBox"));
                startActivityForResult(Intent.createChooser(i, audio ? "Kies geluid" : "Kies achtergrond"), REQ_FILE);
                return true;
            }
        });
        ensureFolder();
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    /** Maakt Download/JetZon BluupBox met een uitleg-bestand, zodat de map bestaat en vindbaar is. */
    private void ensureFolder() {
        if (Build.VERSION.SDK_INT < 29 || prefs().getBoolean("folderMade", false)) return;
        try {
            android.content.ContentValues cv = new android.content.ContentValues();
            cv.put(android.provider.MediaStore.Downloads.DISPLAY_NAME, "LEESMIJ.txt");
            cv.put(android.provider.MediaStore.Downloads.MIME_TYPE, "text/plain");
            cv.put(android.provider.MediaStore.Downloads.RELATIVE_PATH, "Download/JetZon BluupBox");
            Uri u = getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (u != null) {
                java.io.OutputStream os = getContentResolver().openOutputStream(u);
                if (os != null) {
                    os.write(("JetZon BluupBox\n\nZet hier je eigen geluid (stereo WAV: links zoem, rechts bluups) en je achtergrond-afbeelding.\n"
                            + "Kies ze daarna in de app via Eigen geluid en Eigen achtergrond. De app onthoudt je keuze.\n"
                            + "Je ritlogs komen ook in deze map.\n").getBytes("UTF-8"));
                    os.close();
                }
            }
            prefs().edit().putBoolean("folderMade", true).apply();
        } catch (Exception ignored) {}
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE && fileCb != null) {
            Uri u = (res == RESULT_OK && data != null) ? data.getData() : null;
            fileCb.onReceiveValue(u == null ? null : new Uri[]{u});
            fileCb = null;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        js("window.onAndroidPerm && window.onAndroidPerm(" + JSONObject.quote(permState()) + ")");
    }

    @Override
    protected void onPause() { testGas = 0f; super.onPause(); }

    @Override
    public void onBackPressed() { moveTaskToBack(true); }   // terug-knop sluit de app niet af

    private void js(String code) { runOnUiThread(() -> web.evaluateJavascript(code, null)); }

    private boolean granted(String p) { return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }

    private String permState() {
        try {
            JSONObject o = new JSONObject();
            o.put("location", granted(Manifest.permission.ACCESS_FINE_LOCATION));
            o.put("notifications", Build.VERSION.SDK_INT < 33 || granted("android.permission.POST_NOTIFICATIONS"));
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            o.put("battery", pm.isIgnoringBatteryOptimizations(getPackageName()));
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    /** Zonder locatietoestemming mag een locatie-voorgrondservice niet starten: eerst vragen. */
    private boolean needLocation() {
        if (granted(Manifest.permission.ACCESS_FINE_LOCATION)) return false;
        runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_PERM));
        return true;
    }

    private SharedPreferences prefs() { return getSharedPreferences("bluup", MODE_PRIVATE); }

    /** Methoden die de HTML-voorkant kan aanroepen via window.Android.* */
    public class Bridge {
        @JavascriptInterface public String permissions() { return permState(); }

        /** Eigen geluid opslaan: stereo WAV (links zoem, rechts bluups), als base64. Geeft "ok" of een foutmelding. */
        @JavascriptInterface public String setSound(String b64) {
            try {
                byte[] all = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
                BluupSynth.fromStereo(all);   // eerst controleren
                java.io.FileOutputStream fo = new java.io.FileOutputStream(new java.io.File(getFilesDir(), "eigen_geluid.wav"));
                fo.write(all); fo.close();
                testSynth = null;
                return "ok";
            } catch (Exception e) { return "Dit bestand werkt niet: " + e.getMessage(); }
        }
        /** Achtergrond bewaren als bestand in de app (data-URL van de geschaalde JPEG). */
        @JavascriptInterface public void setBackground(String dataUrl) {
            java.io.File f = new java.io.File(getFilesDir(), "achtergrond.txt");
            if (dataUrl == null || dataUrl.isEmpty()) { f.delete(); return; }
            try (java.io.FileOutputStream fo = new java.io.FileOutputStream(f)) { fo.write(dataUrl.getBytes("UTF-8")); } catch (Exception ignored) {}
        }
        @JavascriptInterface public String getBackground() {
            java.io.File f = new java.io.File(getFilesDir(), "achtergrond.txt");
            if (!f.exists()) return "";
            try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
                byte[] b = new byte[(int) f.length()]; int off = 0, n; while (off < b.length && (n = in.read(b, off, b.length - off)) > 0) off += n;
                return new String(b, "UTF-8");
            } catch (Exception e) { return ""; }
        }

        /** Eigen karakter (transparante PNG als data-URL) bewaren in de app. */
        @JavascriptInterface public void setCharacter(String dataUrl) { saveText("karakter.txt", dataUrl); }
        @JavascriptInterface public String getCharacter() { return loadText("karakter.txt"); }
        private void saveText(String name, String v) {
            java.io.File f = new java.io.File(getFilesDir(), name);
            if (v == null || v.isEmpty()) { f.delete(); return; }
            try (java.io.FileOutputStream fo = new java.io.FileOutputStream(f)) { fo.write(v.getBytes("UTF-8")); } catch (Exception ignored) {}
        }
        private String loadText(String name) {
            java.io.File f = new java.io.File(getFilesDir(), name);
            if (!f.exists() || f.length() > 40_000_000L) return "";
            try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
                byte[] b = new byte[(int) f.length()]; int off = 0, n; while (off < b.length && (n = in.read(b, off, b.length - off)) > 0) off += n;
                return new String(b, "UTF-8");
            } catch (Exception e) { return ""; }
        }

        @JavascriptInterface public void clearSound() { new java.io.File(getFilesDir(), "eigen_geluid.wav").delete(); testSynth = null; }
        @JavascriptInterface public boolean hasSound() { return new java.io.File(getFilesDir(), "eigen_geluid.wav").exists(); }

        /** Testgas 0..1 vanuit de schuif op het scherm. */
        @JavascriptInterface public void testGas(float g) {
            if (!Float.isFinite(g)) g = 0f;
            g = Math.max(0f, Math.min(1f, g));
            if (g > 0.001f || testGas > 0.001f) testIdleSince = System.currentTimeMillis();
            testGas = g;
            if (g > 0.02f && !testRun) startTest();
        }

        @JavascriptInterface public void requestLocation() {
            runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_PERM));
        }

        @JavascriptInterface public void requestNotifications() {
            if (Build.VERSION.SDK_INT >= 33) runOnUiThread(() -> requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_PERM));
            else js("window.onAndroidPerm && window.onAndroidPerm(" + JSONObject.quote(permState()) + ")");
        }

        @JavascriptInterface public void openBattery() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
                }
            });
        }

        @JavascriptInterface public void openAppSettings() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))));
        }

        @JavascriptInterface public void setConfig(String json) {
            try {
                JSONObject o = new JSONObject(json);
                SharedPreferences.Editor ed = prefs().edit();
                String v = o.has("voertuig") ? o.getString("voertuig") : prefs().getString("voertuig", "efiets");
                if (o.has("vmax")) { ed.putFloat("vmax", (float) o.getDouble("vmax")); ed.putFloat(v + "_vmax", (float) o.getDouble("vmax")); }
                if (o.has("speaker")) ed.putString("speaker", o.getString("speaker"));
                if (o.has("zoem")) ed.putFloat("zoem", (float) o.getDouble("zoem"));
                if (o.has("spacing")) ed.putFloat("spacing", (float) o.getDouble("spacing"));
                if (o.has("voertuig")) ed.putString("voertuig", o.getString("voertuig"));
                ed.apply();
            } catch (Exception ignored) {}
        }

        @JavascriptInterface public void activate() { if (needLocation()) return; JetsonService.start(MainActivity.this, JetsonService.ACTION_ACTIVE); }
        @JavascriptInterface public void calibrate() { if (needLocation()) return; JetsonService.start(MainActivity.this, JetsonService.ACTION_CALIBRATE); }
        @JavascriptInterface public void stop() { JetsonService.start(MainActivity.this, JetsonService.ACTION_STOP); }

        @JavascriptInterface public String status() {
            try {
                JSONObject o = new JSONObject();
                o.put("running", JetsonService.running);
                o.put("mode", JetsonService.mode);
                o.put("speed", JetsonService.speedKmh);
                o.put("gps", JetsonService.gpsOk);
                o.put("moving", JetsonService.moving);
                o.put("forward", JetsonService.forwardKnown);
                Calibrator c = JetsonService.calibrator;
                if (c != null) {
                    o.put("calStep", c.step);
                    o.put("calCount", c.countdown);
                    o.put("calMsg", c.message);
                    o.put("calVmax", c.vmaxKmh);
                }
                o.put("vmaxMeasured", prefs().getFloat(prefs().getString("voertuig", "efiets") + "_vmaxMeasured", 0));
                o.put("sleeping", JetsonService.sleeping);
                return o.toString();
            } catch (Exception e) { return "{}"; }
        }
    }
}
